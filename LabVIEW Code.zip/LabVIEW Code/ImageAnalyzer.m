clc; clear; close all

% I = screencapture(0);
% imwrite(I,'C:\Users\fireg\OneDrive\Desktop\Images\myImage.png')

I = imread('C:\Users\fireg\OneDrive\Desktop\Images\myImage.png');
imshow(I)

J = histeq(I);


G = im2gray(J);
imshow(G)

figure(1)
BW = ~imbinarize(G,124/255);
imshow(BW)

[H, theta, rho] = hough(BW);

figure(2)
peaks  = houghpeaks(H,10);
imshow(H,[],'XData',theta,'YData',rho,'InitialMagnification','fit');
xlabel('\theta'), ylabel('\rho');
axis on, axis normal, hold on;
plot(theta(peaks(:,2)),rho(peaks(:,1)),'s','color','white');

lines = houghlines(BW,theta,rho,peaks,'FillGap',5,'MinLength',7);

figure(3)
imshow(BW)
hold on
%empty vectors to store the u and v coordinates of end points of lines from
%hough transform
u_hough = nan(length(lines),2);
v_hough = nan(length(lines),2);
line_eq_coef = nan(length(lines),2);

for ii = 1:length(lines)
   xy = [lines(ii).point1; lines(ii).point2];
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');

   u_hough(ii,:) = [lines(ii).point1(1) lines(ii).point2(1)];
   v_hough(ii,:) = [lines(ii).point1(2) lines(ii).point2(2)];

   line_eq_coef(ii,:) = polyfit(u_hough(ii,:),v_hough(ii,:),1);
end
title('Lines Detected')

theta_vect = [lines(:).theta];
chan_ind = find(max(theta_vect - median(theta_vect)));
ridge_angle = abs(median(theta_vect(theta_vect ~= theta_vect(chan_ind))) - theta_vect(chan_ind));
ridge_lines = line_eq_coef;
ridge_lines(chan_ind,:) = [];
ridge_lines_sorted = sortrows(ridge_lines,2);

ridge_dist = nan(1,length(ridge_lines_sorted)-1);
for ii = 1:length(ridge_dist)
    ridge_dist(ii) = ridge_lines_sorted(ii+1,2) - ridge_lines_sorted(ii,2);
end

avg_ridge_distance = mean(ridge_dist);
saveas(figure(3),'C:\Users\fireg\OneDrive\Desktop\Images\Analyzed.png')